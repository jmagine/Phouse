
public class driver {
	public static void main(String[] args) {
		ComputerPort cp = new ComputerPort();
		cp.updateState();
	}
}
